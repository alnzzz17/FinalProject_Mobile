import 'package:flutter_compass/flutter_compass.dart';
import 'package:mockito/annotations.dart';

@GenerateMocks([CompassEvent])
void main() {}
