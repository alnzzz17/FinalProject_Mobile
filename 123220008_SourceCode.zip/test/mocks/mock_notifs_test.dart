import 'package:mockito/annotations.dart';
import 'package:tpm_fp/network/notification_service.dart';

@GenerateMocks([NotificationService])
void main() {}